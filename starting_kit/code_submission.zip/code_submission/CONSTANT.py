
NUMERICAL_TYPE = "num"
NUMERICAL_PREFIX = "f8_"

CATEGORY_TYPE = "cat"
CATEGORY_PREFIX = "O_"

TIME_TYPE = "time"
TIME_PREFIX = "M8_"

MULTI_CAT_TYPE = "multi-cat"
MULTI_CAT_PREFIX = "O_"
MULTI_CAT_DELIMITER = ","

POS_MULTI_CAT_PREFIX = "cm_"


MAIN_TABLE_NAME = "main"
MAIN_TABLE_TEST_NAME = "main_test"
TABLE_PREFIX = "table_"

LABEL = "label"

HASH_MAX = 200
